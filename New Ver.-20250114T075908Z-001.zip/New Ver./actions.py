from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import SlotSet, FollowupAction

class ActionSetActiveCollege(Action):
    def name(self) -> Text:
        return "action_set_active_college"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        message = tracker.latest_message.get('text', '').lower()
        
        # Enhanced college mappings with more keywords
        college_keywords = {
            'ccs': ['ccs', 'computer', 'computing', 'it', 'information technology', 'programming'],
            'coe': ['coe', 'engineering', 'engineer'],
            'csm': ['csm', 'science', 'math', 'mathematics'],
            'cbaa': ['cbaa', 'business', 'accountancy', 'accounting'],
            'cass': ['cass', 'arts', 'social sciences', 'sociology'],
            'ced': ['ced', 'education', 'teaching'],
            'chs': ['chs', 'health', 'nursing']
        }

        # Get current context
        current_college = tracker.get_slot('active_college')
        current_topic = tracker.get_slot('active_topic')
        
        # Determine new college from message
        new_college = None
        for college, keywords in college_keywords.items():
            if any(keyword in message for keyword in keywords):
                new_college = college
                break

        events = []
        if new_college:
            # If switching colleges, track the change
            if current_college and new_college != current_college:
                events.append(SlotSet("last_topic", current_college))
                events.append(SlotSet("conversation_stage", "switching"))
            
            events.extend([
                SlotSet("active_college", new_college),
                SlotSet("active_topic", f"{new_college}_general")
            ])
        
        return events

class ActionHandleContextSwitch(Action):
    def name(self) -> Text:
        return "action_handle_context_switch"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        active_college = tracker.get_slot('active_college')
        last_topic = tracker.get_slot('last_topic')
        conversation_stage = tracker.get_slot('conversation_stage')
        
        if conversation_stage == "switching":
            if last_topic:
                # Acknowledge the topic switch
                dispatcher.utter_message(response="utter_help_refocus")
            return [SlotSet("conversation_stage", "inquiring")]
        
        return []

class ActionHandleFollowUp(Action):
    def name(self) -> Text:
        return "action_handle_follow_up"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        active_college = tracker.get_slot('active_college')
        active_topic = tracker.get_slot('active_topic')
        
        # Handle follow-up based on current context
        if active_college == 'ccs':
            if 'programs' in active_topic:
                dispatcher.utter_message(text="Would you like to know about:\n1. Admission requirements\n2. Course curriculum\n3. Career opportunities")
            elif 'facilities' in active_topic:
                dispatcher.utter_message(text="Would you like to know about:\n1. Laboratory equipment\n2. Research facilities\n3. Study areas")
        
        return [SlotSet("conversation_stage", "following_up")]

class ActionTrackConversation(Action):
    def name(self) -> Text:
        return "action_track_conversation"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        # Get current state
        current_intent = tracker.latest_message.get('intent', {}).get('name')
        active_college = tracker.get_slot('active_college')
        conversation_stage = tracker.get_slot('conversation_stage')
        
        events = []
        
        # Track conversation progression
        if not conversation_stage:
            events.append(SlotSet("conversation_stage", "initial"))
        elif conversation_stage == "initial" and active_college:
            events.append(SlotSet("conversation_stage", "inquiring"))
        
        # Log conversation state for debugging
        print(f"Current Intent: {current_intent}")
        print(f"Active College: {active_college}")
        print(f"Conversation Stage: {conversation_stage}")
        
        return events